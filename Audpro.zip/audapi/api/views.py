from django.shortcuts import render
from django.http import HttpResponse
from django.views.decorators.csrf import csrf_protect
import json
import datetime
from api.models import song,podcast,audiobook

def index(request):
    response = json.dumps([{}])
    return HttpResponse(response, content_type='text/json')

def get_det(request ,dtype, ID=None):
    res1=''    
    if request.method == 'GET' and dtype=='song':
            if ID==None:
                response= song.objects.all()
                
                for res in response:
                    res1 = res1 + json.dumps([{"ID=":res.id,"name":res.name,"duration":res.duration,"upload time":str(res.uploaded)}])
            else:
                res= song.objects.get(id=ID)
                res1= json.dumps([{"ID=":res.id,"name":res.name,"duration":res.duration,"upload time":str(res.uploaded)}])

    elif  request.method == 'GET' and dtype=='podcast':
            if ID==None:
                response= podcast.objects.all()
                for res in response:
                    res1= res1 + json.dumps([{"ID=":res.id,"name":res.name,"duration":res.duration,"upload time":str(res.uploaded),"host":res.host,"participants":res.participants}]) 
            else:
                res= podcast.objects.get(id=ID)
                res1= json.dumps([{"ID=":res.id,"name":res.name,"duration":res.duration,"upload time":str(res.uploaded),"host":res.host,"participants":res.participants}])

    elif  request.method == 'GET' and dtype=='audiobook':
            if ID==None:
                response= audiobook.objects.all()
                for res in response:
                    res1=res1 + json.dumps([{"ID=":res.id,"title":res.title,"duration":res.duration,"upload time":str(res.uploaded),"author":res.author,"narrator":res.narrator}])
            else:
                res= audiobook.objects.get(id=ID)
                res1=json.dumps([{"ID=":res.id,"title":res.title,"duration":res.duration,"upload time":str(res.uploaded),"author":res.author,"narrator":res.narrator}])
   
    
    return HttpResponse(res1, content_type='text/json')
def add_det(request):
    if request.method == 'POST':
        payload = json.loads(request.body)
        dtype = payload["audioFileType"]
        meta = payload["audioFileMetadata"]
        if (dtype=="song"):

            aud = song(id=payload["id"],name=meta["name"], duration=meta["duration"] , uploaded=meta["uploaded"] )
            aud.save()
            flag=1

        elif (dtype=="podcast"):
            aud = podcast(id=payload["id"],name=meta["name"] , duration=meta["duration"] , uploaded=meta["uploaded"] ,host=meta["host"],participants=meta["participants"] )
            if len(meta["participants"])>10:
                aud=""
                flag=0
            else:
                flag=1
        
        elif(dtype=='audiobook'):
             aud = audiobook(id=payload["id"],title=meta['title'], author=meta['author'] , uploaded=meta['uploaded'] ,narrator=meta['narrator'],duration=meta['duration'])
             aud.save()
             flag=1
        if (flag==1):
            response = json.dumps([{ 'Success': 'Data added successfully!'}])
            #response = json.dumps([{ 'Error': 'Data could not be added!'}])
    return HttpResponse(response, content_type='text/json')

def delete(request,dtype,ID):
    flag=0
    if request.method=='DELETE':
        if dtype=="song":
            rem=song.objects.get(id=ID)
            rem.delete()
            flag=1
        elif dtype=="podcast":
            rem=podcast.objects.get(id=ID)
            rem.delete()
            flag=1
        elif dtype=="audiobook":
            rem=audiobook.objects.get(id=ID)
            rem.delete()
            flag=1
    if flag==1:
        response = json.dumps([{ 'Success': 'Data deleted successfully!'}])
    return HttpResponse(response, content_type='text/json')


def update(request,dtype,ID):
    if request.method == 'POST':
        payload = json.loads(request.body) 
        meta = payload["audioFileMetadata"]
        newid=payload["id"]
        if (dtype=="song"):
            response= song.objects.filter(id=ID).update(id=newid,name=meta["name"],duration=meta["duration"],uploaded=meta["uploaded"])  
            if response:
                flag=1
            else:
                flag=0

        elif (dtype=="podcast"):
            response= podcast.objects.filter(id=ID).update(id=newid,name=meta["name"] , duration=meta["duration"] , uploaded=meta["uploaded"] ,host=meta["host"],participants=meta["participants"] )
            if response:
                flag=1
            else:
                flag=0
        
        elif(dtype=="audiobook"):
            response= audiobook.objects.filter(id=ID).update(id=newid,title=meta['title'], author=meta['author'] , uploaded=meta['uploaded'] ,narrator=meta['narrator'],duration=meta['duration'])
            if response:
                flag=1
            else:
                flag=0
    if flag==1:
        response = json.dumps([{ 'Success': 'Data updated successfully!'}])
    else:    
        response = json.dumps([{ 'Error': 'Data could not be updated!'}])
    return HttpResponse(response, content_type='text/json')


def validator(datetime):
    if datetime < timezone.now().datetime:
        raise ValidationError("past date not acceptable")
# Create your views here.
