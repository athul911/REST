from django.db import models
from django_mysql.models import ListCharField
import datetime

# Create your models here.
class song(models.Model):
    name = models.CharField(max_length=100)
    duration=models.PositiveIntegerField()
    uploaded=models.DateTimeField(default=datetime.datetime.now())


class podcast(models.Model):
    name = models.CharField(max_length=100)
    duration=models.PositiveIntegerField()
    uploaded=models.DateTimeField(default=datetime.datetime.now())
    host = models.CharField(max_length=100)
    participants= ListCharField(base_field=models.CharField(max_length=100),size=10,max_length=(10 * 101))

class audiobook(models.Model):
    title = models.CharField(max_length=100)
    author = models.CharField(max_length=100)
    narrator = models.CharField(max_length=100)
    duration=models.PositiveIntegerField()
    uploaded=models.DateTimeField(default=datetime.datetime.now())