I have used mysql,not sqllite3
Endpoints:
localhost/get[/<audiotype>/<ID=id>]
localhost/create
localhost/delete[/<audiotype>/<ID=id>]
localhost/update[/<audiotype>/<ID=id>]